# -*- coding: utf-8 -*-
"""
Created on Tue Jan  9 08:16:26 2024

@author: A408565
"""
# Importing libraries
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, cross_val_predict
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score


st.header('Sustainability App')
st.subheader('''
             The page is divided into two sections:
                 1. Exploratory Data Analysis
                 2. Predictive Analysis
             ''')

options = st.selectbox('Section',['Exploratory Data Analysis', 'Predictive Analysis'])            
 
#st.write("""
         # 
#         """)
df= pd.read_csv('CO2_Emissions_Canada.csv')
if options == 'Exploratory Data Analysis':
    
    st.dataframe(df)
    st.markdown('<iframe title="ExploratoryDataAnalysis" width="1140" height="541.25" src="https://app.powerbi.com/reportEmbed?reportId=6be689dc-b2df-4cd3-b544-6728ef7413e8&autoAuth=true&ctid=f25493ae-1c98-41d7-8a33-0be75f5fe603" frameborder="0" allowFullScreen="true"></iframe>', unsafe_allow_html=True)         

else:
    print("Correlation Matrix")
    #plt.rcParams['figure.figsize']=(8,6)
    fig = plt.figure(figsize=(12, 5))
    sns.heatmap(df.corr(),cmap='coolwarm',linewidths=.5,fmt=".2f",annot = True)
    st.pyplot(fig)
   
    df.drop(['Make','Model','Vehicle Class','Fuel Consumption City (L/100 km)','Fuel Consumption Hwy (L/100 km)','Transmission','Fuel Consumption Comb (mpg)'],inplace=True,axis=1)
    
    result = df.copy()
    X = result.drop(['CO2 Emissions(g/km)','Fuel Type'], axis= 1)
    y = result["CO2 Emissions(g/km)"]
  
    
    X = (X - np.min(X)) / (np.max(X) - np.min(X)).values
  
    
    X_train, X_test, y_train, y_test = train_test_split(X,
                                                        y, 
                                                        test_size=0.25, 
                                                        random_state=42)
    
    #print("X_train", X_train.shape)
    
    #print("y_train",y_train.shape)
    
    #print("X_test",X_test.shape)
    
    #print("y_test",y_test.shape)
  
    
    lm = LinearRegression()
    model = lm.fit(X_train, y_train)
    
    #print(np.sqrt(mean_squared_error(y_train, model.predict(X_train))))
    predictions = model.predict(X_test)
    text_input = st.text_input("Enter Engine Size(L)")
    text_input = st.text_input("Enter Cylinders")
    text_input = st.text_input("Enter Fuel Consumption Comb (L/100 km)")
    st.button('Predict Co2 emissions')
    #if st.button('Predict type of Iris'):
        #result = predict(np.array([[Engine Size(L), Cylinders, Fuel Consumption Comb (L/100 km)]]))
        #st.text(result)    
#%%
#st.text('Exploratory Data Analysis')

#cd C:\Users\A408565\Desktop\example
#streamlit run streamlitapp.py
#import subproces
#subprocess.run(["streamlit", "run", "streamlitapp.py"])
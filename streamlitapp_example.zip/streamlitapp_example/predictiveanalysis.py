

# Import necessary libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_squared_error
import numpy as np

df= pd.read_csv(r'C:\Users\A408565\Desktop\example\CO2_Emissions_Canada.csv')
result = df.copy()
result = result.rename(columns={'Vehicle Class': 'VehicleClass', 'Engine Size(L)': 'EngineSize', 'Fuel Type': 'FuelType', 'Fuel Consumption City (L/100 km)': 'FuelConsumptionCity',
       'Fuel Consumption Hwy (L/100 km)': 'FuelConsumptionHwy', 'Fuel Consumption Comb (L/100 km)': 'FuelConsumptionComb_L','Fuel Consumption Comb (mpg)': 'FuelConsumptionComb_mpg', 'CO2 Emissions(g/km)': 'CO2Emissions'})
X = result.drop(['CO2Emissions','Model',
              'Transmission', 'FuelType'], axis= 1)
y = result["CO2Emissions"]

X_train, X_test, y_train, y_test = train_test_split(X,
                                        y, 
                                        test_size=0.25, 
                                        random_state=42)
#%%
# Define the preprocessing steps
numeric_features = ['EngineSize', 'Cylinders', 'FuelConsumptionCity', 'FuelConsumptionHwy',
       'FuelConsumptionComb_L', 'FuelConsumptionComb_mpg']
categorical_features = ['Make', 'VehicleClass']#, 'Model','Transmission', 'FuelType'

numeric_transformer = Pipeline(steps=[
    ('scaler', 'passthrough')  # No scaling for numeric feature in this example
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder())
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
        ('cat', categorical_transformer, categorical_features)
    ])

# Create the pipeline with preprocessing and linear regression
lm = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', LinearRegression())
])

# Fit the model
lm.fit(X_train, y_train)

#print(np.sqrt(mean_squared_error(y_train, model.predict(X_train))))
y_pred = lm.predict(X_test)
#%%
# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
print(f'Mean Squared Error: {mse}')
#%%
# Example prediction
example_prediction = lm.predict(pd.DataFrame({'NumericFeature': [6], 'CategoricalFeature': ['A']}))
print(f'Example Prediction: {example_prediction[0]}')
